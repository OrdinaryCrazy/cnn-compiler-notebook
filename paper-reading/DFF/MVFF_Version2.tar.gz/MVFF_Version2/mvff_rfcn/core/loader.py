# --------------------------------------------------------
# Rivulet
# Licensed under The MIT License [see LICENSE for details]
# Modified by Boyuan Feng
# --------------------------------------------------------
# --------------------------------------------------------
# Deep Feature Flow
# Copyright (c) 2017 Microsoft
# Licensed under The MIT License [see LICENSE for details]
# Modified by Xizhou Zhu, Yuwen Xiong
# --------------------------------------------------------
# Based on:
# MX-RCNN
# Copyright (c) 2016 by Contributors
# Licence under The Apache 2.0 License
# https://github.com/ijkguo/mx-rcnn/
# --------------------------------------------------------

import numpy as np
import mxnet as mx
from mxnet.executor_manager import _split_input_slice

from config.config import config
from utils.image import tensor_vstack, transform
from rpn.rpn import get_rpn_testbatch_mv, get_rpn_pair_mv_batch, assign_anchor
from rcnn import get_rcnn_testbatch, get_rcnn_batch
import copy
import cv2

class TestLoader(mx.io.DataIter):
    def __init__(self, roidb, feat_conv_3x3_relu, config, batch_size=1, shuffle=False,
                 has_rpn=False):
        super(TestLoader, self).__init__()

        self.feat_conv_3x3_relu = feat_conv_3x3_relu

        # save parameters as properties
        self.cfg = config
        self.roidb = roidb
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.has_rpn = has_rpn

        # infer properties from roidb
        self.size = np.sum([x['frame_seg_len'] for x in self.roidb])
        self.index = np.arange(self.size)

        # decide data and label names (only for training)
        self.data_name = ['data', 'im_info', 'data_key', 'motion_vector', 'feat_key']
        self.label_name = None

        #
        self.cur_roidb_index = 0
        self.cur_frameid = 0
        self.data_key = None
        self.key_frameid = 0
        self.cur_seg_len = 0
        self.key_frame_flag = -1

        # status variable for synchronization between get_data and get_label
        self.cur = 0
        self.data = None
        self.label = []
        self.im_info = None
        self.extend_data = None

        # get first batch to fill in provide_data and provide_label
        self.reset()
        self.get_batch()

    @property
    def provide_data(self):
        if self.key_frame_flag == 0 or self.key_frame_flag == 1:
            # print('Provide_Data, key frame')
            #tmp = self.data_name[:]
            #tmp.remove('motion_vector')
            #tmp.remove('feat_key')
            self.data_name = ['data', 'im_info', 'data_key']
            # ['data', 'im_info', 'data_key']
            # print('provide_data(), key frame, len(self.data): ', len(self.data[0]))
            if len(self.data[0]) == 5:
                self.data = [[mx.nd.array(self.data[0][0]), mx.nd.array(self.data[0][1]), mx.nd.array(self.data[0][2])]]
            data = [[(k, v.shape) for k, v in zip(self.data_name, self.data[0])]]
            return data
        else:
            # print('Provide_Data, non-key frame')
            # print('Provide_Data(), non-key frame, len(self.data[0]): ', len(self.data[0]), '\n\n')
            # tmp_data_name = self.data_name[:]
            # tmp_data_name.remove('data')
            # tmp_data_name.remove('data_key')
            self.data_name = ['im_info', 'motion_vector', 'feat_key']
            # ['im_info', 'motion_vector', 'feat_key']
            # print('provide_data(), non-key frame, tmp_data_name: ', tmp_data_name)
            if len(self.data[0]) == 5:
                self.data = [[mx.nd.array(self.data[0][1]), mx.nd.array(self.data[0][3]), mx.nd.array(self.data[0][4])]]
                # print('Provide_Data(), non-key frame, after assignment, len(self.data[0]): ', len(self.data[0]), '\n\n')
            tmp = [[(k, v.shape) for k, v in zip(self.data_name, self.data[0])]]
            return tmp


    @property
    def provide_label(self):
        return [None for _ in range(len(self.data))]

    @property
    def provide_data_single(self):
        if self.key_frame_flag == 0 or self.key_frame_flag == 1:
            tmp = ['data', 'im_info', 'data_key']
            if len(self.extend_data) == 5:
                tmp_data = [[mx.nd.array(self.extend_data['data']), mx.nd.array(self.extend_data['im_info']), mx.nd.array(self.extend_data['data_key'])]]
                data = [(k, v.shape) for k, v in zip(tmp, tmp_data[0])]
            else:
                data = [(k, v.shape) for k, v in zip(tmp, self.data[0])]
            return data
        else:
            tmp_data_name = ['im_info', 'motion_vector', 'feat_key']
            if len(self.extend_data) == 5:
                tmp_data = [[mx.nd.array(self.extend_data['im_info']), mx.nd.array(self.extend_data['motion_vector']), mx.nd.array(self.extend_data['feat_key'])]]
                data = [(k, v.shape) for k, v in zip(tmp_data_name, tmp_data[0])]
            else:
                data = [(k, v.shape) for k, v in zip(tmp_data_name, self.data[0])]

            return data

    @property
    def provide_data_single_test_initialization(self):
        # print('self.extend_data: ', self.extend_data)
        tmp_data_name = ['im_info', 'motion_vector', 'feat_key']
        if len(self.extend_data) == 5:
            tmp = [[mx.nd.array(self.extend_data['im_info']), mx.nd.array(self.extend_data['motion_vector']), mx.nd.array(self.extend_data['feat_key'])]]
            # print('provide_data_single_test_initialization(), second, self.data: ', self.data)
        tmp = [(k, v.shape) for k, v in zip(tmp_data_name, tmp[0])]
        # print('Provide_Data(), tmp: ', tmp)
        return tmp

    @property
    def provide_label_single(self):
        return None

    def reset(self):
        self.cur = 0
        if self.shuffle:
            np.random.shuffle(self.index)

    def iter_next(self):
        return self.cur < self.size

    def next(self):
        if self.iter_next():
            self.get_batch()
            self.cur += self.batch_size
            self.cur_frameid += 1
            if self.cur_frameid == self.cur_seg_len:
                self.cur_roidb_index += 1
                self.cur_frameid = 0
                self.key_frameid = 0
            elif self.cur_frameid - self.key_frameid == self.cfg.TEST.KEY_FRAME_INTERVAL:
                self.key_frameid = self.cur_frameid
            return self.im_info, self.key_frame_flag, mx.io.DataBatch(data=self.data, label=self.label,
                                   pad=self.getpad(), index=self.getindex(),
                                   provide_data=self.provide_data, provide_label=self.provide_label)
        else:
            raise StopIteration

    def getindex(self):
        return self.cur / self.batch_size

    def getpad(self):
        if self.cur + self.batch_size > self.size:
            return self.cur + self.batch_size - self.size
        else:
            return 0

    def get_batch(self):
        # Original process
        cur_roidb = self.roidb[self.cur_roidb_index].copy()
        cur_roidb['image'] = cur_roidb['pattern'] % self.cur_frameid

        # print('get_batch(), cur_roidb[\'image\']: ', cur_roidb['image'])


        self.cur_seg_len = cur_roidb['frame_seg_len']
        data, label, im_info = get_rpn_testbatch_mv([cur_roidb], self.cfg)

        # Resize motion vector
        data_shape = {k: v.shape for k, v in data[0].items()}
        del data_shape['im_info']
        del data_shape['motion_vector']
        _, feat_shape, _ = self.feat_conv_3x3_relu.infer_shape(**data_shape)
        # print('get_batch(), data[0][\'motion_vector\']: ', data[0]['motion_vector'], ', data[0][\'motion_vector\'].shape: ', data[0]['motion_vector'].shape)
        data[0]['motion_vector'] = data[0]['motion_vector'].astype('float64')
        data[0]['motion_vector'] = cv2.resize(data[0]['motion_vector'], (int(feat_shape[0][3]), int(feat_shape[0][2])), interpolation = cv2.INTER_AREA)
        data[0]['motion_vector'] = transform(data[0]['motion_vector'], [0,0])
        # print('get_batch(), data[0][\'motion_vector\']: ', data[0]['motion_vector'], ', data[0][\'motion_vector\'].shape: ', data[0]['motion_vector'].shape)

        # Original process
        if self.key_frameid == self.cur_frameid: # key frame
            self.data_key = data[0]['data'].copy()
            if self.key_frameid == 0:
                self.key_frame_flag = 0
            else:
                self.key_frame_flag = 1
        else:
            self.key_frame_flag = 2


        self.data_name = ['data', 'im_info', 'data_key', 'motion_vector', 'feat_key']
        extend_data = [{'data': data[0]['data'],
                        'im_info': data[0]['im_info'],
                        'data_key': self.data_key,
                        'motion_vector': data[0]['motion_vector'],
                        'feat_key': np.zeros((1,self.cfg.network.DFF_FEAT_DIM,1,1))}]
        self.extend_data = extend_data[0]
        self.data = [[mx.nd.array(extend_data[i][name]) for name in self.data_name] for i in xrange(len(data))]
        self.im_info = im_info


        if self.key_frame_flag == 0 or self.key_frame_flag == 1:
            self.data_name = ['data', 'im_info', 'data_key']
            if len(self.data[0]) == 5:
                self.data = [[mx.nd.array(self.data[0][0]), mx.nd.array(self.data[0][1]), mx.nd.array(self.data[0][2])]]
            # print('get_batch(), key frame, self.data: ', self.data)
        else:
            self.data_name = ['im_info', 'motion_vector', 'feat_key']
            if len(self.data[0]) == 5:
                self.data = [[mx.nd.array(self.data[0][1]), mx.nd.array(self.data[0][3]), mx.nd.array(self.data[0][4])]]
                # print('get_batch(), self.data: ', self.data)
            # print('get_batch(), non-key frame, self.data: ', self.data)


class AnchorLoader(mx.io.DataIter):

    def __init__(self, feat_sym, feat_conv_3x3_relu, roidb, cfg, batch_size=1, shuffle=False, ctx=None, work_load_list=None,
                 feat_stride=16, anchor_scales=(8, 16, 32), anchor_ratios=(0.5, 1, 2), allowed_border=0,
                 aspect_grouping=False, normalize_target=False, bbox_mean=(0.0, 0.0, 0.0, 0.0),
                 bbox_std=(0.1, 0.1, 0.4, 0.4)):
        """
        This Iter will provide roi data to Fast R-CNN network
        :param feat_sym: to infer shape of assign_output
        :param roidb: must be preprocessed
        :param batch_size: must divide BATCH_SIZE(128)
        :param shuffle: bool
        :param ctx: list of contexts
        :param work_load_list: list of work load
        :param aspect_grouping: group images with similar aspects
        :param normalize_target: normalize rpn target
        :param bbox_mean: anchor target mean
        :param bbox_std: anchor target std
        :return: AnchorLoader
        """
        super(AnchorLoader, self).__init__()

        # save parameters as properties
        self.feat_sym = feat_sym
        self.feat_conv_3x3_relu = feat_conv_3x3_relu
        self.roidb = roidb
        self.cfg = cfg
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.ctx = ctx
        if self.ctx is None:
            self.ctx = [mx.cpu()]
        self.work_load_list = work_load_list
        self.feat_stride = feat_stride
        self.anchor_scales = anchor_scales
        self.anchor_ratios = anchor_ratios
        self.allowed_border = allowed_border
        self.aspect_grouping = aspect_grouping
        self.normalize_target = normalize_target
        self.bbox_mean = bbox_mean
        self.bbox_std = bbox_std

        # infer properties from roidb
        self.size = len(roidb)
        self.index = np.arange(self.size)

        # decide data and label names
        if config.TRAIN.END2END:
            # self.data_name = ['data', 'data_ref', 'eq_flag', 'im_info', 'gt_boxes', 'motion_vector']
            self.data_name = ['data_ref', 'eq_flag', 'im_info', 'gt_boxes', 'motion_vector']
        else:
            self.data_name = ['data']
        self.label_name = ['label', 'bbox_target', 'bbox_weight']

        # status variable for synchronization between get_data and get_label
        self.cur = 0
        self.batch = None
        self.data = None
        self.label = None

        # get first batch to fill in provide_data and provide_label
        self.reset()
        self.get_batch_individual()

    @property
    def provide_data(self):
        return [[(k, v.shape) for k, v in zip(self.data_name, self.data[i])] for i in xrange(len(self.data))]

    @property
    def provide_label(self):
        return [[(k, v.shape) for k, v in zip(self.label_name, self.label[i])] for i in xrange(len(self.data))]

    @property
    def provide_data_single(self):
        return [(k, v.shape) for k, v in zip(self.data_name, self.data[0])]

    @property
    def provide_label_single(self):
        return [(k, v.shape) for k, v in zip(self.label_name, self.label[0])]

    def reset(self):
        self.cur = 0
        if self.shuffle:
            if self.aspect_grouping:
                widths = np.array([r['width'] for r in self.roidb])
                heights = np.array([r['height'] for r in self.roidb])
                horz = (widths >= heights)
                vert = np.logical_not(horz)
                horz_inds = np.where(horz)[0]
                vert_inds = np.where(vert)[0]
                inds = np.hstack((np.random.permutation(horz_inds), np.random.permutation(vert_inds)))
                extra = inds.shape[0] % self.batch_size
                inds_ = np.reshape(inds[:-extra], (-1, self.batch_size))
                row_perm = np.random.permutation(np.arange(inds_.shape[0]))
                inds[:-extra] = np.reshape(inds_[row_perm, :], (-1,))
                self.index = inds
            else:
                np.random.shuffle(self.index)

    def iter_next(self):
        return self.cur + self.batch_size <= self.size

    def next(self):
        if self.iter_next():
            self.get_batch_individual()
            self.cur += self.batch_size
            return mx.io.DataBatch(data=self.data, label=self.label,
                                   pad=self.getpad(), index=self.getindex(),
                                   provide_data=self.provide_data, provide_label=self.provide_label)
        else:
            raise StopIteration

    def getindex(self):
        return self.cur / self.batch_size

    def getpad(self):
        if self.cur + self.batch_size > self.size:
            return self.cur + self.batch_size - self.size
        else:
            return 0

    def infer_shape(self, max_data_shape=None, max_label_shape=None):
        """ Return maximum data and label shape for single gpu """
        if max_data_shape is None:
            max_data_shape = []
        if max_label_shape is None:
            max_label_shape = []
        max_shapes = dict(max_data_shape + max_label_shape)
        input_batch_size = max_shapes['data_ref'][0]
        im_info = [[max_shapes['data_ref'][2], max_shapes['data_ref'][3], 1.0]]
        _, feat_shape, _ = self.feat_sym.infer_shape(**max_shapes)
        label = assign_anchor(feat_shape[0], np.zeros((0, 5)), im_info, self.cfg,
                              self.feat_stride, self.anchor_scales, self.anchor_ratios, self.allowed_border,
                              self.normalize_target, self.bbox_mean, self.bbox_std)
        label = [label[k] for k in self.label_name]
        label_shape = [(k, tuple([input_batch_size] + list(v.shape[1:]))) for k, v in zip(self.label_name, label)]
        return max_data_shape, label_shape


    def get_batch(self):
        # slice roidb
        cur_from = self.cur
        cur_to = min(cur_from + self.batch_size, self.size)
        roidb = [self.roidb[self.index[i]] for i in range(cur_from, cur_to)]

        # decide multi device slice
        work_load_list = self.work_load_list
        ctx = self.ctx
        if work_load_list is None:
            work_load_list = [1] * len(ctx)
        assert isinstance(work_load_list, list) and len(work_load_list) == len(ctx), \
            "Invalid settings for work load. "
        slices = _split_input_slice(self.batch_size, work_load_list)

        # get testing data for multigpu
        data_list = []
        label_list = []
        for islice in slices:
            iroidb = [roidb[i] for i in range(islice.start, islice.stop)]
            data, label = get_rpn_pair_mv_batch(iroidb, self.cfg)
            data_list.append(data)
            label_list.append(label)

        # pad data first and then assign anchor (read label)
        data_tensor = tensor_vstack([batch['data'] for batch in data_list])
        for data, data_pad in zip(data_list, data_tensor):
            data['data'] = data_pad[np.newaxis, :]

        new_label_list = []
        for data, label in zip(data_list, label_list):
            # infer label shape
            #for k, v in data.items():
            #    print(k, v)
            data_shape = {k: v.shape for k, v in data.items()}
            del data_shape['im_info']
            _, feat_shape, _ = self.feat_sym.infer_shape(**data_shape)
            feat_shape = [int(i) for i in feat_shape[0]]

            # add gt_boxes to data for e2e
            data['gt_boxes'] = label['gt_boxes'][np.newaxis, :, :]

            # assign anchor for label
            label = assign_anchor(feat_shape, label['gt_boxes'], data['im_info'], self.cfg,
                                  self.feat_stride, self.anchor_scales,
                                  self.anchor_ratios, self.allowed_border,
                                  self.normalize_target, self.bbox_mean, self.bbox_std)
            new_label_list.append(label)

        all_data = dict()
        for key in self.data_name:
            all_data[key] = tensor_vstack([batch[key] for batch in data_list])

        all_label = dict()
        for key in self.label_name:
            pad = -1 if key == 'label' else 0
            all_label[key] = tensor_vstack([batch[key] for batch in new_label_list], pad=pad)

        self.data = [mx.nd.array(all_data[key]) for key in self.data_name]
        self.label = [mx.nd.array(all_label[key]) for key in self.label_name]

    def get_batch_individual(self):
        cur_from = self.cur
        cur_to = min(cur_from + self.batch_size, self.size)
        roidb = [self.roidb[self.index[i]] for i in range(cur_from, cur_to)]
        # decide multi device slice
        work_load_list = self.work_load_list
        ctx = self.ctx
        if work_load_list is None:
            work_load_list = [1] * len(ctx)
        assert isinstance(work_load_list, list) and len(work_load_list) == len(ctx), \
            "Invalid settings for work load. "
        slices = _split_input_slice(self.batch_size, work_load_list)
        rst = []
        for idx, islice in enumerate(slices):
            iroidb = [roidb[i] for i in range(islice.start, islice.stop)]
            rst.append(self.parfetch(iroidb))
        all_data = [_['data'] for _ in rst]
        all_label = [_['label'] for _ in rst]

        # print('all_data: ', all_data)

        # self.data_name = ['data', 'data_ref', 'eq_flag', 'im_info', 'gt_boxes', 'motion_vector']
        self.data = [[mx.nd.array(data[key]) for key in self.data_name] for data in all_data]
        # self.label_name = ['label', 'bbox_target', 'bbox_weight']
        self.label = [[mx.nd.array(label[key]) for key in self.label_name] for label in all_label]

        '''
        print('self.data: ', self.data)
        print('type(self.data): ', type(self.data))
        print('len(self.data): ', len(self.data))
        print('type(self.data[0]): ', type(self.data[0]))
        '''


    def parfetch(self, iroidb):
        # get testing data for multigpu
        data, label = get_rpn_pair_mv_batch(iroidb, self.cfg)

        #for k, v in data.items():
        #    print(k, v)
        data_shape = {k: v.shape for k, v in data.items()}
        #print(data_shape)
        del data_shape['im_info']
        del data_shape['data']

        data_shape1 = copy.deepcopy(data_shape)
        del data_shape1['eq_flag']
        del data_shape1['motion_vector']
        _, feat_shape, _ = self.feat_conv_3x3_relu.infer_shape(**data_shape1)
        #print('feat_shape: ', feat_shape)

        #print('shape: ', data['motion_vector'].shape)
        #print("size: ", int(feat_shape[0][2]), int(feat_shape[0][3]))
        data['motion_vector'] = data['motion_vector'].astype('float64')
        data['motion_vector'] = cv2.resize(data['motion_vector'], (int(feat_shape[0][3]), int(feat_shape[0][2])), interpolation = cv2.INTER_AREA)
        #print('data[\'motion_vector\'].shape: ', data['motion_vector'].shape)
        data['motion_vector'] = transform(data['motion_vector'], [0,0])
        #print('data[\'motion_vector\'].shape: ', data['motion_vector'].shape)
        #print("data['motion_vector']: ", data['motion_vector'])
        #data['motion_vector'] = cv2.resize(data['motion_vector'], (36, 63))
        data_shape = {k: v.shape for k, v in data.items()}
        #print(data_shape)
        del data_shape['im_info']
        del data_shape['data']


        _, feat_shape, _ = self.feat_sym.infer_shape(**data_shape)
        feat_shape = [int(i) for i in feat_shape[0]]

        # add gt_boxes to data for e2e
        data['gt_boxes'] = label['gt_boxes'][np.newaxis, :, :]

        # assign anchor for label
        label = assign_anchor(feat_shape, label['gt_boxes'], data['im_info'], self.cfg,
                              self.feat_stride, self.anchor_scales,
                              self.anchor_ratios, self.allowed_border,
                              self.normalize_target, self.bbox_mean, self.bbox_std)
        return {'data': data, 'label': label}

